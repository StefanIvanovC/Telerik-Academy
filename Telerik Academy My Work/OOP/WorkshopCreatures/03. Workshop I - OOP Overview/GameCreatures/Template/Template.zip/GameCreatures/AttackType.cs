﻿namespace GameCreatures
{
    public enum AttackType
    {
        Ranged,
        Melee,
        Magic
    }
}
