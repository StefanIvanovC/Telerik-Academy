﻿namespace GameCreatures
{
    public enum ArmorType
    {
        Light,
        Medium,
        Heavy
    }
}
