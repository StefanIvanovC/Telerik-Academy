﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BoardR
{
    // List of BoardItems - we must be able to add items to the board
    static class Board
    {
        public static List<BoardItem> items = new List<BoardItem>();

    }
}
