﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BoardR
{
    public enum Status
    {
        Open,
        Todo,
        InProgress,
        Done,
        Verified
    }
}
